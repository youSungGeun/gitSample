import hello from './hello.js';
import world from './world.js';
document.getElementById("root").innerHTML = hello.message + world.message;
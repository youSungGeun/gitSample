var message = 'World';

export default {
    message: message
};
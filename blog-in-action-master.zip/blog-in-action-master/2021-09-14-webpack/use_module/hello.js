var message = 'Hello';

export default {
    message: message
};
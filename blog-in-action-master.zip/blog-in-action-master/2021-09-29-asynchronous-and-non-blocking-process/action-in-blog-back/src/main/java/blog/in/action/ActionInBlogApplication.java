package blog.in.action;

public class ActionInBlogApplication {

    public static void main(String[] args) {

    }
}

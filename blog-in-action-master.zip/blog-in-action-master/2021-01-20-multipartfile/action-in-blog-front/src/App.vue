<template>
    <FileUpload />
</template>

<script>
import FileUpload from './components/FileUpload.vue'

export default {
    name: 'App',
    components: {
        FileUpload
    }
}
</script>
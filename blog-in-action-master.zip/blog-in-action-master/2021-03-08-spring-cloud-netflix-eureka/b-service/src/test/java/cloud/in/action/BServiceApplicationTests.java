package cloud.in.action;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
